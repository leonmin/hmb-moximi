// const mainURL = "https://api-test.jkhelper.com/api.php" 
// const mainURL = "https://api-dev.jkhelper.com/api.php"
const mainURL = "https://api.jkhelper.com/api.php"


export default {
	mainURL
}